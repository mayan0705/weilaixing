</<template>
    <div>
        <div id="usersmessage">
        <mybutton type-theme='publish'>发表</mybutton><label>user:
            </label><mybutton type-theme='logout'>
                注销</mybutton>
        </div> 
    </div>    
</template>
<script>
import card from './components/card.vue'
import mybutton from './components/mybutton.vue'
export default {
    name:"app1",
    props:{

    },
    components:{
        mybutton,
        card
    }
}
</script>

