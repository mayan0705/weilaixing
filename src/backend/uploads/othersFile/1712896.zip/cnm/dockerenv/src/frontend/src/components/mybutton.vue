<template>

    <button type="submit" :id="typeTheme" onclick="change"><slot></slot></button>

</template>

<script>
export default {
    name:'mybutton',
    props:{
        typeTheme:
        {
            type:String,
            default:'login'
        }
    },
    methods:{//添加一些按钮的功能如提交数据到数据库
    }

}
</script>

<style scoped>
#login{
    width: 98px;
    height: 40px;
    background: #2188E9;
    box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.10);
    color: #FFFFFF;
    border-radius: 15px;
    border: 0px;
    padding: 9px;
    font-size: 16px;
    font-family: PingFangSC-Regular;
    position: relative;
}
#register{
    width: 98px;
    height: 40px;
    background: #2188E9;
    box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.10);
    color: #FFFFFF;
    border-radius: 15px;
    border: 0px;
    padding: 9px;
    font-size: 16px;
    font-family: PingFangSC-Regular;
    position: relative;
    left:30px;
}
#zan{
    width: 98px;
    height: 40px;
    background: #2188E9;
    box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.10);
    color: #FFFFFF;
    border-radius: 15px;
    border: 0px;
    padding: 9px;
    font-size: 16px;
    font-family: PingFangSC-Regular;
    position: relative;
    left:250px;
}
#cai{
    width: 98px;
    height: 40px;
    background: #2188E9;
    box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.10);
    color: #FFFFFF;
    border-radius: 15px;
    border: 0px;
    padding: 9px;
    font-size: 16px;
    font-family: PingFangSC-Regular;
    position: relative;
    left:270px;

}
#logout{
    width: 98px;
    height: 40px;
    background: #2188E9;
    box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.10);
    color: #FFFFFF;
    border-radius: 15px;
    border: 0px;
    padding: 9px;
    font-size: 16px;
    font-family: PingFangSC-Regular;
    position: relative;
}
#publish{
    width: 98px;
    height: 40px;
    background: #2188E9;
    box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.10);
    color: #FFFFFF;
    border-radius: 15px;
    border: 0px;
    padding: 9px;
    font-size: 16px;
    font-family: PingFangSC-Regular;
    position: relative;
    left:200px;
    top:250px;
}
</style>
