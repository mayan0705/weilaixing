from django.shortcuts import render
from django.shortcuts import redirect
from rest_framework import viewsets
from .models import K_board
from .models import Message
from .serializers import K_boardSerializer
from .serializers import MessageSerializer
# Create your views here.


class K_boardView(viewsets.ModelViewSet):
    queryset = K_board.objects.all()
    serializer_class = K_boardSerializer

class MessageView(viewsets.ModelViewSet):
    queryset=Message.objects.all()
    serializer_class=MessageSerializer


def login(request):
    error_msg = ""
    print('cnmcnmcncmcncmcncnn')
    if request.name == "cnm":
        user = request.get('user', None)
        password = request.get('password', None)
        if user == 'root' and password == "123":

            return redirect('127:0.0.1:8002/admin')
        else:
            error_msg = "Wrong username or password."
    return render(request, '127:0.0.1:8002/admin', {'error_msg': error_msg})
