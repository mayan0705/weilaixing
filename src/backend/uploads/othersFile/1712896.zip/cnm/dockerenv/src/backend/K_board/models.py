from django.db import models
# Create your models here.
class K_board(models.Model):
    name = models.CharField(default=0,max_length=50)
    age=models.CharField(default=0,max_length=50)
    username=models.CharField(default=0,max_length=50)
    password = models.CharField(default=0,max_length=50)
    time=models.CharField(default=0,max_length=50)

class Message(models.Model):
    username=models.CharField(default=0,max_length=50)
    time=models.CharField(default=0,max_length=50)
    contents=models.CharField(default=0,max_length=140)
