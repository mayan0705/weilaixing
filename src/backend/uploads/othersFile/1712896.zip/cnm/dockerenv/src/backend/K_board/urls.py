from django.urls import path, include
from . import views
from rest_framework import routers

router=routers.DefaultRouter()
router.register('K_board',views.K_boardView)
router.register('Message',views.MessageView)
urlpatterns=[
    path('',include(router.urls)),
    path('',views.login,name='login')
]