<template>
    <label :id="input1"><slot></slot><input :id="input" ref="kkk"  type="text" @focus="zfocus" ></label>
</template>

<script>
export default {
    name:"inputs",
    props:{
        input1:{
        type:String,
        default:"user1"
        },
        input:{
            type:String,
            default:"user"
        }

    },
    methods:{
        zfocus(){
            if(this.input=="password")
            {
                this.$refs.kkk.type="password";
            }
        }

    }
}

</script>
<style>
#user1 {
    width: 120px;
    height: 30px;
    margin: 0px;
    border-radius: 5px;
    border: 0px;
    font-size: 30px;
}

#user {
    width: 120px;
    height: 30px;
    border-radius: 5px;
    border: 0px;
    background: #FFFFFF;
    box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.10);
    font-family: PingFangSC-Regular;
    color: rgb(0, 0, 0);
    font-size: 16px;
    padding:0px;
    position: relative;
}
#password1 {
    width: 120px;
    height: 30px;
    margin: 0px;
    border-radius: 5px;
    border: 0px;
    font-size: 30px;
}

#password {
    width: 120px;
    height: 30px;
    border-radius: 5px;
    border: 0px;
    background: #FFFFFF;
    box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.10);
    font-family: PingFangSC-Regular;
    color: #000000;
    font-size: 16px;
    padding:0px;
    position: relative;
}


</style>