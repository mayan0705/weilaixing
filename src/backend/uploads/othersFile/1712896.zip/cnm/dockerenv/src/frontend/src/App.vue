<template>
  <div id="app"> 
    <mybutton type-theme='publish'  id="publish">发表</mybutton>
    <HelloWorld msg="Welcome to K-board!"/>
    <p>LDY@All rights Reserved</p>
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue'
import mybutton from './components/mybutton.vue'
export default {
  name: 'App',
  components: {
    HelloWorld,
    mybutton,
  },
}
</script>

<style scoped>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  margin-top: 100px;

}
 p {
   position: relative;
   text-align:center;
 }
</style>
