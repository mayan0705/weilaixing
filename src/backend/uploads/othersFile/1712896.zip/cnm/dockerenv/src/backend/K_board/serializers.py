from rest_framework import serializers
from .models import K_board
from .models import Message
class K_boardSerializer(serializers.ModelSerializer):
    class Meta:
        model = K_board
        fields = ('id', 'name','age','username', 'password','time')
class MessageSerializer(serializers.ModelSerializer):
    class Meta:
        model=Message
        fields=('id','username','time','content')