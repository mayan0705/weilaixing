from django.apps import AppConfig


class KBoardConfig(AppConfig):
    name = 'K_board'
