from django.contrib import admin
from .models import K_board
from .models import Message
# Register your models here.
admin.site.register(K_board)
admin.site.register(Message)
