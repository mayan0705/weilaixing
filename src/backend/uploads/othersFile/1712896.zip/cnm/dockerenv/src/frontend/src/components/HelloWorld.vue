<template>
  <div class="hello">
    <form  action="http://localhost:8002/K_board/K_board/?format=json" method="get" target="_blank">  
    <div id="log">
    <lables input1='user1' input='user' type='text'>用户名：</lables><lables input1='password1' input='password' type='password'>密码：</lables> <mybutton type-theme='login'>Login</mybutton><mybutton type-theme='register'>Register</mybutton>
    <br>
    <br>
    </div>
    </form>
    <p>{{ msg }}</p>
    <card content="在这里输入内容..."/>
    <card content="在这里输入内容..."/>
    <card content="在这里输入内容..."/>
    <card content="在这里输入内容..."/>
    <card content="在这里输入内容..."/>
  </div>
</template>

<script>
import mybutton from './mybutton.vue'
import lables from './lables.vue'
import card from './card.vue'
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  },
  components:{
    mybutton,
    lables,
    card
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
p{
  font-size:99px;
  text-align: center;
  vertical-align: middle;
}
#log{
  position:relative;
  left:65%;
}
.hello{
  position:relative;
  bottom:50px;
}


</style>
