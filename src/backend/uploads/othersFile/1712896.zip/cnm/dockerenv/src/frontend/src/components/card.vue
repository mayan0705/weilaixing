<template>
<div id='card'>
    <textarea>在这里输入内容...</textarea>
    <br>
    <br>
    <mybutton type-theme='zan'>赞</mybutton><mybutton type-theme='cai'>踩</mybutton>
    <br>
    <br>
</div>
</template>

<script>
import mybutton from "./mybutton.vue"
export default {
    name: 'card',
    components: {
        mybutton,
    },
}
</script>

<style>
#card {
    position: relative;
    text-align: center;
}

textarea {
    width: 700px;
    height: 100px;
    background-color:rgb(224, 184, 123);
    font-size: 20px;
}
</style>
